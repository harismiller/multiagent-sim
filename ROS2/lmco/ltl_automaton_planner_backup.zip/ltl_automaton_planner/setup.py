from setuptools import setup
from setuptools import find_packages
from glob import glob
import os

package_name = 'ltl_automaton_planner'

setup(
    name=package_name,
    version='0.0.0',
    packages=['ltl_automaton_planner'],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    author='Jiming Ren',
    author_email='jren313@gatech.edu',
    keywords=['ROS'],
    description='For Isaac.',
    license='Apache License, Version 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'planner_node = ltl_automaton_planner.nodes.planner_node:main',
            'benchmark_node = ltl_automaton_planner.nodes.benchmark_node:main',
        ],
    },
)